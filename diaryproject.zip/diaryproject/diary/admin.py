from django.contrib import admin
from .models import Diary,Todo

admin.site.register(Diary)
admin.site.register(Todo)
